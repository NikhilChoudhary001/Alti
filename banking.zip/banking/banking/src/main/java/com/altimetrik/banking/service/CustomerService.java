package com.altimetrik.banking.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.altimetrik.banking.model.Customer;
import com.altimetrik.banking.model.Payee;
import com.altimetrik.banking.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	public void addCustomer(Customer customer) {
		
		customerRepository.save(customer);
		
	}

	public Customer getCustomer(int accountNumber) {
				
		Optional<Customer> customer = customerRepository.findById(accountNumber);
		
		return customer.get();
				
	}

	public void addBeneficiary(Payee payee, Long accountNumber) {
		
		customerRepository.savePayee(payee,accountNumber);
	}
	
	

}
