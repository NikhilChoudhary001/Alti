package com.altimetrik.banking.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.altimetrik.banking.model.Customer;
import com.altimetrik.banking.model.Payee;

public interface CustomerRepository extends CrudRepository<Customer, Integer>{

	@Transactional
	@Modifying
	@Query("update Customer c set c.payee = ?1 where c.accountNumber = ?2")
	void savePayee(Payee payee, Long accountNumber);

}
