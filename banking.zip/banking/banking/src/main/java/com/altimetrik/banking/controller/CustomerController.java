package com.altimetrik.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.banking.model.Customer;
import com.altimetrik.banking.model.Payee;
import com.altimetrik.banking.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	
	@PostMapping("/add")
	public void addCustomer(@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) @RequestBody Customer customer){
		
		customerService.addCustomer(customer);
		
	}
	
	@GetMapping(value = "/getCustomer")
	public Customer getCustomer(@RequestParam(required = true) int accountNumber){
		
		Customer customer =	customerService.getCustomer(accountNumber);
		return customer;
		
	}
	
	@PostMapping("/addBeneficiary")
	public void addBeneficiary( @RequestBody Payee payee, @RequestHeader Long accountNumber){
		
		customerService.addBeneficiary(payee,accountNumber);
		
	}

}
