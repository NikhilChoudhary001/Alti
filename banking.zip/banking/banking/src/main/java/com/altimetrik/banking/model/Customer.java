package com.altimetrik.banking.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer implements Serializable{
	
	@Id
	private int accountNumber;
	
	private String name;
	private LocalDateTime lastVisitedDate;
	private Double balance;
	
	@OneToMany(mappedBy = "accountNumber")
	//@JoinColumn(name = "accountNumber", nullable = false)
	List<Payee> payee;
    
	
	public Customer(){
		
	}

	public Customer(int accountNumber, String name, LocalDateTime lastVisitedDate, Double balance, List<Payee> payee) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.lastVisitedDate = lastVisitedDate;
		this.balance = balance;
		this.payee = payee;
	}



	public int getAccountNumber() {
		return accountNumber;
	}



	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public LocalDateTime getLastVisitedDate() {
		return lastVisitedDate;
	}



	public void setLastVisitedDate(LocalDateTime lastVisitedDate) {
		this.lastVisitedDate = lastVisitedDate;
	}



	public Double getBalance() {
		return balance;
	}



	public void setBalance(Double balance) {
		this.balance = balance;
	}



	public List<Payee> getPayee() {
		return payee;
	}



	public void setPayee(List<Payee> payee) {
		this.payee = payee;
	}
	

}
